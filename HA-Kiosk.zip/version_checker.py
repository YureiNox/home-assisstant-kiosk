import json
import requests
import platform

def get_current_version():
    with open('version.json') as json_file:
        data = json.load(json_file)
        return data['version']
    
def get_current_os():
    return platform.system()

print(f"{get_current_version()}, {get_current_os()}")